from distutils.core import setup

setup(
    name='weather',
    version='0.1dev',
    packages=['weather'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
#    long_description=open('README.txt').read(),
)
